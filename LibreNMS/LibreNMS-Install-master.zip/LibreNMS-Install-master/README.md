# LibreNMS-Install
A batch script to install LibNMS on Ubuntu 18.04 LTS  Originally.</br>
I have updated the script to work on Ubuntu 22.04 LTS <br>

