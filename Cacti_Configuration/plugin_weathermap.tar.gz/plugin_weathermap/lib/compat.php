<?php

    $colors = array();
    /* colors */
    $colors[ "dark_outline" ]         = "454E53";
    $colors[ "dark_bar" ]             = "AEB4B7";
    $colors[ "panel" ]                = "E5E5E5";
    $colors[ "panel_text" ]           = "000000";
    $colors[ "panel_link" ]           = "000000";
    $colors[ "light" ]                = "F5F5F5";
    $colors[ "alternate" ]            = "E7E9F2";
    $colors[ "panel_dark" ]           = "C5C5C5";
    $colors[ "header" ]               = "00438C";
    $colors[ "header_panel" ]         = "6d88ad";
    $colors[ "header_text" ]          = "ffffff";
    $colors[ "form_background_dark" ] = "E1E1E1";
    $colors[ "form_alternate1" ]      = "F5F5F5";
    $colors[ "form_alternate2" ]      = "E5E5E5";
