<?php

header("Location:../../logout.php");
// vim:ts=4:sw=4:
